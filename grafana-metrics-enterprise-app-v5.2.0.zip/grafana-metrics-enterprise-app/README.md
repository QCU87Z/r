# Grafana Enterprise Metrics

Grafana Enterprise Metrics (GEM) is a commercial offering based on the open-source project Mimir.
The commercial offering allows you to deploy a higly-scalable, simple, and reliable metrics cluster in your own data center.
This app plugin gives you an easy way to manage your metrics cluster.

## Features

- **Tenant management** Easily scale up to hundreds of metrics tenants on a single Metrics Enterprise cluster.
- **Access policies and tokens**  Fully control and visualize who has access to what.
- **Ring health** Give an overview on the current status of the various service rings in the cluster.

## Dashboards

- **Self-monitoring** GEM includes the ability to directly record self-monitoring metrics to allow you to easily monitor the health and stability of GEM itself.
  A set of self-monitoring dashboards is made available, using GEM's self-monitoring metrics to help monitor GEM system health.
- **Cardinality management** GEM provides the ability to understand the cardinality of your metrics and labels using cardinality management dashboards to help visualize and explore the data from the cardinality management API.

## Configuration

After the plugin has been [installed](https://grafana.com/grafana/plugins/grafana-metrics-enterprise-app/?tab=installation) into your Grafana instance, enable and initialize it:

1. Navigate to **Administration** > **Plugins and data** > **Plugins**
1. Select the **Grafana Enterprise Metrics** app from the list of plugins.
1. If an alert indicates that _this app plugin is not enabled_, enable the plugin by clicking on the **Enable** button. The alert text will indicate where it can be found.
1. Ensure that the **Connection settings** section is filled out using the bootstrap token for your GEM, and the corresponding URL where the cluster can be accessed by the Grafana instance.
1. Start using the **Grafana Enterprise Metrics** app plugin.
